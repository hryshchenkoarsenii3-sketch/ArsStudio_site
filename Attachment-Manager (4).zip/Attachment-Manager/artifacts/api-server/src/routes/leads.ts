import { Router, type IRouter } from "express";
import { ReplitConnectors } from "@replit/connectors-sdk";
import { CreateLeadBody, CreateLeadResponse } from "@workspace/api-zod";

const router: IRouter = Router();
const connectors = new ReplitConnectors();
const TELEGRAM_CHAT_ID = process.env["TELEGRAM_LEADS_CHAT_ID"] ?? "1372771151";

const botTypeLabels: Record<string, string> = {
  webapp: "Telegram WebApp (TMA)",
  ai: "ШІ-бот",
  ecommerce: "E-commerce",
  crm: "CRM-автоматизація",
  other: "Інше",
};

function escapeTelegramHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

router.post("/leads", async (req, res) => {
  const parsed = CreateLeadBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "Перевірте заповнення всіх полів форми." });
    return;
  }

  const lead = parsed.data;
  const text = [
    "<b>Нова заявка з ARS Studio</b>",
    "",
    `<b>Ім’я:</b> ${escapeTelegramHtml(lead.name)}`,
     `<b>Контакт:</b> ${escapeTelegramHtml(lead.contact)}`,
    `<b>Тип бота:</b> ${escapeTelegramHtml(botTypeLabels[lead.botType] ?? lead.botType)}`,
    "",
    "<b>Опис завдання:</b>",
    escapeTelegramHtml(lead.description),
  ].join("\n");

  try {
    const telegramResponse = await connectors.proxy("telegram", "/sendMessage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text,
        parse_mode: "HTML",
      }),
    });

    const telegramResult = (await telegramResponse.json()) as {
      ok?: boolean;
      description?: string;
    };

    if (!telegramResponse.ok || !telegramResult.ok) {
      req.log.error(
        { status: telegramResponse.status, description: telegramResult.description },
        "Telegram rejected lead",
      );
      res.status(502).json({ error: "Не вдалося надіслати заявку в Telegram." });
      return;
    }

    const response = CreateLeadResponse.parse({
      ok: true,
      message: "Заявку надіслано.",
    });
    res.json(response);
  } catch (error) {
    req.log.error({ err: error }, "Telegram lead delivery failed");
    res.status(502).json({ error: "Не вдалося надіслати заявку в Telegram." });
  }
});

export default router;