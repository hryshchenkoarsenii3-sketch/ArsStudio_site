/* GENERATED FROM tokens.json -- DO NOT EDIT. Run scripts/build-tokens.mjs. */
// Portable design tokens (colors as hex). Web consumes the theme via
// src/index.css; mobile (Expo) and any other platform import this object so the
// whole product shares one source of truth.
export const tokens = {
  "color": {
    "light": {
      "background": "#f0f6ff",
      "foreground": "#0a1628",
      "border": "#b8d4ee",
      "card": "#ffffff",
      "cardForeground": "#0a1628",
      "popover": "#ffffff",
      "popoverForeground": "#0a1628",
      "primary": "#0075bb",
      "primaryForeground": "#ffffff",
      "secondary": "#d8edfc",
      "secondaryForeground": "#0a1628",
      "muted": "#e4f0fb",
      "mutedForeground": "#4a6785",
      "accent": "#0095d9",
      "accentForeground": "#ffffff",
      "destructive": "#dc2626",
      "destructiveForeground": "#ffffff",
      "input": "#b8d4ee",
      "ring": "#0088cc",
      "chart1": "#0075bb",
      "chart2": "#0095d9",
      "chart3": "#6c3aff",
      "chart4": "#00aa66",
      "chart5": "#e53e3e",
      "sidebar": "#e4f0fb",
      "sidebarForeground": "#0a1628",
      "sidebarBorder": "#b8d4ee",
      "sidebarPrimary": "#0075bb",
      "sidebarPrimaryForeground": "#ffffff",
      "sidebarAccent": "#d8edfc",
      "sidebarAccentForeground": "#0a1628",
      "sidebarRing": "#0075bb"
    },
    "dark": {
      "background": "#090d17",
      "foreground": "#e8f4fd",
      "border": "#1e3050",
      "card": "#0d1829",
      "cardForeground": "#e8f4fd",
      "popover": "#0d1829",
      "popoverForeground": "#e8f4fd",
      "primary": "#0088cc",
      "primaryForeground": "#ffffff",
      "secondary": "#1a2744",
      "secondaryForeground": "#a8c8e8",
      "muted": "#111827",
      "mutedForeground": "#6b8fb5",
      "accent": "#00d2ff",
      "accentForeground": "#000a14",
      "destructive": "#ef4444",
      "destructiveForeground": "#ffffff",
      "input": "#1e3050",
      "ring": "#0088cc",
      "chart1": "#0088cc",
      "chart2": "#00d2ff",
      "chart3": "#7c5aff",
      "chart4": "#00e887",
      "chart5": "#ff6b6b",
      "sidebar": "#0d1829",
      "sidebarForeground": "#a8c8e8",
      "sidebarBorder": "#1e3050",
      "sidebarPrimary": "#0088cc",
      "sidebarPrimaryForeground": "#ffffff",
      "sidebarAccent": "#1a2744",
      "sidebarAccentForeground": "#e8f4fd",
      "sidebarRing": "#0088cc"
    }
  },
  "fontFamily": {
    "sans": [
      "Inter",
      "sans-serif"
    ],
    "serif": [
      "Montserrat",
      "sans-serif"
    ],
    "mono": [
      "JetBrains Mono",
      "monospace"
    ]
  },
  "radius": "0.625rem",
  "spacing": "0.25rem"
} as const;

export type Tokens = typeof tokens;
export default tokens;
