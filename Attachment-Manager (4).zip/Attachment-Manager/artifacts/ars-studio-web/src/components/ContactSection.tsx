import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { Button } from "@workspace/ars-studio-ds/components/ui/button";
import { Input } from "@workspace/ars-studio-ds/components/ui/input";
import { Textarea } from "@workspace/ars-studio-ds/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@workspace/ars-studio-ds/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@workspace/ars-studio-ds/components/ui/select";
import { toast } from "@workspace/ars-studio-ds/hooks/use-toast";
import { useCreateLead } from "@workspace/api-client-react";
import { Mail, Send } from "lucide-react";
import { useRevealOnMount } from "../hooks/useScrollReveal";

const formSchema = z.object({
  name: z.string().min(2, "Ім’я має містити щонайменше 2 символи"),
  contact: z.string().min(2, "Введіть username або номер телефону"),
  botType: z.string().min(1, "Оберіть тип бота"),
  description: z.string().min(10, "Опишіть завдання детальніше (мінімум 10 символів)"),
});

type FormValues = z.infer<typeof formSchema>;

function formatContact(value: string) {
  if (!value || !/^[+\d]/.test(value.trim())) {
    return value;
  }

  const digits = value.replace(/\D/g, "");
  if (!digits) {
    return "+380";
  }

  const localNumber = digits.startsWith("380")
    ? digits.slice(3)
    : digits.replace(/^0/, "");

  return `+380${localNumber}`.slice(0, 13);
}

const BOT_TYPES = [
  { value: "webapp", label: "Telegram WebApp (TMA)" },
  { value: "ai", label: "ШІ-бот" },
  { value: "ecommerce", label: "E-commerce" },
  { value: "crm", label: "CRM-автоматизація" },
  { value: "other", label: "Інше" },
];

export function ContactSection() {
  const titleRef = useRevealOnMount();
  const createLead = useCreateLead();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      contact: "",
      botType: "",
      description: "",
    },
  });

  function onSubmit(data: FormValues) {
    createLead.mutate(
      { data },
      {
        onSuccess: () => {
          toast({
            title: "Заявку надіслано!",
            description: "Ми зв’яжемося з вами найближчим часом.",
          });
          form.reset();
        },
        onError: () => {
          toast({
            title: "Не вдалося надіслати заявку",
            description: "Спробуйте ще раз або напишіть нам у Telegram.",
            variant: "destructive",
          });
        },
      },
    );
  }

  return (
    <section id="contacts" className="py-24 relative" data-testid="contact-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title */}
        <div ref={titleRef} className="text-center mb-16 reveal-hidden">
          <span
            className="inline-block mb-3 text-xs font-mono text-primary/80 tracking-widest uppercase"
            style={{ fontFamily: "var(--app-font-mono)" }}
          >
             Напишіть нам
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white">
             Зв’язатися з нами
          </h2>
          <p className="mt-4 text-base text-white/50 font-sans max-w-xl mx-auto">
             Залиште заявку — обговоримо проєкт і безкоштовно розрахуємо вартість.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 items-start max-w-5xl mx-auto">
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-40px" }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-3 glass-card rounded-2xl p-8"
          >
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(onSubmit)}
                className="flex flex-col gap-5"
                data-testid="contact-form"
              >
                {/* Name */}
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                       <FormLabel className="text-white/70 font-sans text-sm">Ім’я</FormLabel>
                      <FormControl>
                        <Input
                           placeholder="Ваше ім’я"
                          className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus-visible:ring-primary/50 font-sans"
                          data-testid="input-name"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage className="text-destructive text-xs" />
                    </FormItem>
                  )}
                />

                {/* Contact */}
                <FormField
                  control={form.control}
                  name="contact"
                  render={({ field }) => (
                    <FormItem>
                       <FormLabel className="text-white/70 font-sans text-sm">Telegram username або номер телефону</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="@username або +380 XX XXX XX XX"
                          className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus-visible:ring-primary/50 font-sans"
                          data-testid="input-contact"
                          {...field}
                          onChange={(event) => field.onChange(formatContact(event.target.value))}
                        />
                      </FormControl>
                      <p className="text-[11px] text-white/35 font-sans">
                        Номер телефону вводьте у форматі +380 XX XXX XX XX
                      </p>
                      <FormMessage className="text-destructive text-xs" />
                    </FormItem>
                  )}
                />

                {/* Bot type */}
                <FormField
                  control={form.control}
                  name="botType"
                  render={({ field }) => (
                    <FormItem>
                       <FormLabel className="text-white/70 font-sans text-sm">Тип бота</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger
                            className="bg-white/5 border-white/10 text-white data-[placeholder]:text-white/30 focus:ring-primary/50 font-sans"
                            data-testid="select-bot-type"
                          >
                             <SelectValue placeholder="Оберіть тип бота" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-card border-border">
                          {BOT_TYPES.map((type) => (
                            <SelectItem
                              key={type.value}
                              value={type.value}
                              className="text-foreground hover:bg-accent font-sans"
                            >
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage className="text-destructive text-xs" />
                    </FormItem>
                  )}
                />

                {/* Description */}
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                       <FormLabel className="text-white/70 font-sans text-sm">Опис завдання</FormLabel>
                      <FormControl>
                        <Textarea
                           placeholder="Розкажіть про ваш проєкт: мета, аудиторія, функціонал..."
                          rows={4}
                          className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus-visible:ring-primary/50 font-sans resize-none"
                          data-testid="textarea-description"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage className="text-destructive text-xs" />
                    </FormItem>
                  )}
                />

                {/* Submit */}
                <Button
                  type="submit"
                  variant="default"
                  disabled={createLead.isPending}
                  className="w-full btn-neon-glow font-sans gap-2 mt-2"
                  data-testid="button-submit"
                >
                  <Send className="w-4 h-4" />
                  {createLead.isPending ? "Надсилання..." : "Надіслати заявку"}
                </Button>
              </form>
            </Form>
          </motion.div>

          {/* Contacts info */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-40px" }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="lg:col-span-2 flex flex-col gap-6"
          >
            {/* Telegram contact */}
            <a
               href="https://t.me/Hryshchenko"
              target="_blank"
              rel="noopener noreferrer"
              className="glass-card rounded-xl p-5 flex items-center gap-4 hover:no-underline group"
              data-testid="link-telegram-contact"
            >
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{
                  background: "rgba(0, 136, 204, 0.12)",
                  border: "1px solid rgba(0, 136, 204, 0.3)",
                }}
              >
                {/* Telegram icon SVG */}
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" style={{ color: "#00d2ff" }}>
                  <path
                    d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm4.93 7.15l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L8.32 14.26l-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.46c.537-.194 1.006.131.864.926z"
                    fill="currentColor"
                  />
                </svg>
              </div>
              <div>
                <p className="text-xs text-white/40 font-sans mb-0.5">Telegram</p>
                <p className="text-base font-semibold text-white group-hover:text-primary transition-colors font-sans">
                   @Hryshchenko
                </p>
              </div>
            </a>

            {/* Email contact */}
            <a
               href="mailto:hryshchenkoarsenii3@gmail.com"
              className="glass-card rounded-xl p-5 flex items-center gap-4 hover:no-underline group"
              data-testid="link-email-contact"
            >
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{
                  background: "rgba(0, 136, 204, 0.12)",
                  border: "1px solid rgba(0, 136, 204, 0.3)",
                }}
              >
                <Mail className="w-6 h-6" style={{ color: "#00d2ff" }} />
              </div>
              <div>
                <p className="text-xs text-white/40 font-sans mb-0.5">Email</p>
                <p className="text-base font-semibold text-white group-hover:text-primary transition-colors font-sans">
                   hryshchenkoarsenii3@gmail.com
                </p>
              </div>
            </a>

            {/* Note card */}
            <div className="glass-card rounded-xl p-5">
              <p className="text-sm text-white/50 font-sans leading-relaxed">
                  Відповідаємо протягом{" "}
                 <span className="text-white/80 font-medium">1 години</span> у робочі дні.
                 Консультація та оцінка проєкту{" "}
                 <span className="text-white/80 font-medium">безкоштовні</span>.
              </p>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Section divider */}
      <div className="section-glow-divider mt-24 mx-8" />
    </section>
  );
}
