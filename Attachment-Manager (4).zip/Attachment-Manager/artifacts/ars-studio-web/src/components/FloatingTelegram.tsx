export function FloatingTelegram() {
  return (
    <a
       href="https://t.me/Hryshchenko"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full flex items-center justify-center telegram-float focus:outline-none"
      style={{
        background: "linear-gradient(135deg, #0088cc 0%, #00d2ff 100%)",
        boxShadow: "0 0 20px rgba(0, 136, 204, 0.5)",
      }}
      data-testid="button-floating-telegram"
       aria-label="Написати в Telegram"
    >
      {/* Telegram SVG icon */}
      <svg
        width="28"
        height="28"
        viewBox="0 0 24 24"
        fill="none"
        style={{ color: "white" }}
      >
        <path
          d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm4.93 7.15l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L8.32 14.26l-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.46c.537-.194 1.006.131.864.926z"
          fill="white"
        />
      </svg>
    </a>
  );
}
