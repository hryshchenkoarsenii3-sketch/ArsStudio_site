const navLinks = [
  { label: "Послуги", href: "#services" },
  { label: "Технології", href: "#tech" },
  { label: "Пакети", href: "#packages" },
  { label: "Етапи роботи", href: "#process" },
  { label: "Контакти", href: "#contacts" },
];

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function scrollToAnchor(href: string) {
  const id = href.replace("#", "");
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
}

export function Footer() {
  return (
    <footer
      className="py-12 border-t font-sans"
      style={{ borderColor: "rgba(0, 136, 204, 0.12)" }}
      data-testid="footer"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          {/* Logo */}
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1 focus:outline-none"
            aria-label="ARS Studio"
            title="ARS Studio"
            data-testid="footer-logo"
          >
            <span className="font-serif font-bold text-xl text-gradient-blue tracking-tight">
              ARS
            </span>
            <span className="font-serif font-light text-xl text-white/80 tracking-tight">
              Studio
            </span>
          </button>

          {/* Nav links */}
          <nav className="flex flex-wrap items-center justify-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => scrollToAnchor(link.href)}
                className="px-3 py-1.5 text-sm text-white/45 hover:text-white/80 transition-colors"
                data-testid={`footer-nav-${link.href.replace("#", "")}`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Copyright */}
          <p className="text-sm text-white/30">
             © 2026 ARS Studio. Усі права захищено.
          </p>
        </div>
      </div>
    </footer>
  );
}
