import { useState, useEffect } from "react";
import { Button } from "@workspace/ars-studio-ds/components/ui/button";
import { cn } from "@workspace/ars-studio-ds/lib/utils";
import { Menu, X } from "lucide-react";

const navLinks = [
  { label: "Послуги", href: "#services" },
  { label: "Технології", href: "#tech" },
  { label: "Пакети", href: "#packages" },
  { label: "Етапи роботи", href: "#process" },
  { label: "Контакти", href: "#contacts" },
];

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function scrollToAnchor(href: string) {
  const id = href.replace("#", "");
  const el = document.getElementById(id);
  if (el) {
    el.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled ? "glass-nav" : "bg-transparent"
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1 focus:outline-none"
            aria-label="ARS Studio"
            title="ARS Studio"
            data-testid="logo-button"
          >
            <span className="font-serif font-bold text-2xl text-gradient-blue tracking-tight">
              ARS
            </span>
            <span className="font-serif font-light text-2xl text-white/90 tracking-tight">
              Studio
            </span>
          </button>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => scrollToAnchor(link.href)}
                className="px-4 py-2 text-sm font-sans text-white/70 hover:text-white transition-colors rounded-md hover:bg-white/5"
                data-testid={`nav-${link.href.replace("#", "")}`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* CTA */}
          <div className="hidden md:flex items-center">
            <Button
              variant="default"
              size="sm"
              className="btn-neon-glow font-sans"
              onClick={() => scrollToAnchor("#contacts")}
              data-testid="button-order-bot"
            >
              Замовити бота
            </Button>
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden flex flex-col gap-1.5 p-2 focus:outline-none"
            onClick={() => setMenuOpen(!menuOpen)}
            data-testid="button-hamburger"
             aria-label="Відкрити меню"
          >
            {menuOpen ? (
              <X className="w-5 h-5 text-white/80" />
            ) : (
              <>
                <span className="hamburger-line" />
                <span className="hamburger-line" />
                <span className="hamburger-line" />
              </>
            )}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden glass-nav border-t border-white/5">
          <div className="px-4 py-4 flex flex-col gap-1">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => {
                  scrollToAnchor(link.href);
                  setMenuOpen(false);
                }}
                className="text-left px-4 py-3 text-sm font-sans text-white/70 hover:text-white transition-colors rounded-md hover:bg-white/5"
                data-testid={`mobile-nav-${link.href.replace("#", "")}`}
              >
                {link.label}
              </button>
            ))}
            <div className="pt-2">
              <Button
                variant="default"
                size="sm"
                className="btn-neon-glow w-full font-sans"
                onClick={() => {
                  scrollToAnchor("#contacts");
                  setMenuOpen(false);
                }}
                data-testid="button-mobile-order"
              >
                 Замовити бота
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
