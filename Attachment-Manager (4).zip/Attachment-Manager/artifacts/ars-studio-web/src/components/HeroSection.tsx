import { useEffect, useRef, useState } from "react";
import { Button } from "@workspace/ars-studio-ds/components/ui/button";
import { cn } from "@workspace/ars-studio-ds/lib/utils";
import backgroundImage from "@assets/generated_images/ars-studio-dark-tech-background.png";

const CYCLE_WORDS = ["Продажів", "WebApps (TMA)", "Нейромереж", "Автоматизації"];
const TYPING_SPEED = 80;
const DELETING_SPEED = 50;
const PAUSE_AFTER_TYPE = 1800;
const PAUSE_AFTER_DELETE = 400;

function scrollToAnchor(id: string) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
}

const PARTICLES = Array.from({ length: 18 }, (_, i) => ({
  id: i,
  top: `${Math.random() * 90}%`,
  left: `${Math.random() * 90}%`,
  duration: `${6 + Math.random() * 8}s`,
  delay: `${Math.random() * 4}s`,
  size: Math.random() > 0.5 ? "4px" : "2px",
  opacity: 0.4 + Math.random() * 0.5,
}));

export function HeroSection() {
  const [displayText, setDisplayText] = useState("");
  const [wordIndex, setWordIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const currentWord = CYCLE_WORDS[wordIndex];

    const tick = () => {
      if (!isDeleting) {
        if (displayText.length < currentWord.length) {
          setDisplayText(currentWord.slice(0, displayText.length + 1));
          timeoutRef.current = setTimeout(tick, TYPING_SPEED);
        } else {
          timeoutRef.current = setTimeout(() => setIsDeleting(true), PAUSE_AFTER_TYPE);
        }
      } else {
        if (displayText.length > 0) {
          setDisplayText(currentWord.slice(0, displayText.length - 1));
          timeoutRef.current = setTimeout(tick, DELETING_SPEED);
        } else {
          setIsDeleting(false);
          setWordIndex((prev) => (prev + 1) % CYCLE_WORDS.length);
          timeoutRef.current = setTimeout(tick, PAUSE_AFTER_DELETE);
        }
      }
    };

    timeoutRef.current = setTimeout(tick, isDeleting ? DELETING_SPEED : TYPING_SPEED);

    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [displayText, isDeleting, wordIndex]);

  return (
    <section
      className="relative min-h-[100dvh] flex flex-col items-center justify-center overflow-hidden"
      data-testid="hero-section"
    >
      {/* Animated background */}
      <div className="hero-bg" style={{ backgroundImage: `url(${backgroundImage})` }}>
        <div className="hero-glow-1" />
        <div className="hero-glow-2" />
        <div className="hero-glow-3" />
        {/* Particles */}
        {PARTICLES.map((p) => (
          <span
            key={p.id}
            className="hero-particle"
            style={{
              top: p.top,
              left: p.left,
              animationDuration: p.duration,
              animationDelay: p.delay,
              width: p.size,
              height: p.size,
              opacity: p.opacity,
            }}
          />
        ))}
        {/* Overlay */}
        <div className="absolute inset-0" style={{ background: "rgba(9, 13, 23, 0.65)" }} />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 mb-8 px-4 py-1.5 rounded-full glass-card text-xs font-mono text-primary border-primary/30">
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          <span className="font-mono" style={{ fontFamily: "var(--app-font-mono)" }}>
             Студія розробки Telegram-ботів
          </span>
        </div>

        {/* Heading with typing animation */}
        <h1
          className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-2"
          data-testid="hero-heading"
        >
          <span className="text-gradient-hero">ARS Studio</span>
          <br />
          <span className="text-white/90 text-3xl sm:text-4xl lg:text-5xl font-semibold">
             розробка Telegram-ботів
          </span>
          <br />
          <span className="text-white/70 text-2xl sm:text-3xl lg:text-4xl font-medium">
             для{" "}
            <span className="text-gradient-blue font-bold">
              {displayText}
            </span>
            <span className="typing-cursor" />
          </span>
        </h1>

        {/* Subheading */}
        <p className="mt-8 text-base sm:text-lg text-white/60 font-sans max-w-2xl mx-auto leading-relaxed">
          Автоматизуємо ваш бізнес, збільшуємо конверсію та заощаджуємо час
          команди за допомогою розумних рішень у Telegram.
        </p>

        {/* CTA Buttons */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button
            variant="default"
            size="lg"
            className="btn-neon-glow font-sans w-full sm:w-auto px-8"
            onClick={() => scrollToAnchor("contacts")}
            data-testid="button-calculate-price"
          >
             Розрахувати вартість
          </Button>
          <Button
            variant="outline"
            size="lg"
            className={cn(
              "font-sans w-full sm:w-auto px-8",
              "border-primary/40 text-white/80 hover:text-white hover:border-primary/70"
            )}
            onClick={() => scrollToAnchor("packages")}
            data-testid="button-demo-bots"
          >
             Пакети та ціни
          </Button>
        </div>

        {/* Stats strip */}
        <div className="mt-14 flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-12">
          {[
             { value: "24/7", label: "Безперебійна робота" },
             { value: "від 2 днів", label: "Швидкий запуск" },
             { value: "100%", label: "Якість і підтримка" },
          ].map((stat, i) => (
            <div
              key={i}
              className="flex flex-col items-center gap-1"
              data-testid={`stat-item-${i}`}
            >
              <span
                className="font-serif font-bold text-2xl text-gradient-blue"
              >
                {stat.value}
              </span>
              <span className="text-sm font-sans text-white/50">{stat.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40">
        <div className="w-px h-8 bg-gradient-to-b from-transparent to-primary/60" />
        <span className="text-xs font-mono text-white/40" style={{ fontFamily: "var(--app-font-mono)" }}>
           scroll
        </span>
      </div>
    </section>
  );
}
