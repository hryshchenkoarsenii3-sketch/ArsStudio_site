import { motion, type Variants } from "framer-motion";
import { Button } from "@workspace/ars-studio-ds/components/ui/button";
import {
  ArrowRight,
  Bot,
  CalendarDays,
  Check,
  Database,
  LayoutDashboard,
  Plug,
  Server,
} from "lucide-react";
import { useRevealOnMount } from "../hooks/useScrollReveal";

const packages = [
  {
    medal: "🥉",
    eyebrow: "Для старту",
    title: "Базовий бот",
    subtitle: "Лід-магніт / Візитка / Заявка",
    icon: Bot,
    color: "#00d2ff",
    features: [
      "Привітання та інлайн-меню",
      "Видача прайсу й інформації",
      "Збір імені та контакту",
      "Надсилання заявки власнику в ПП",
    ],
    stack: "Python · aiogram 3",
    duration: "1–2 дні",
    price: "$40–70",
    priceUah: "≈ 1 600–2 800 грн",
  },
  {
    medal: "🥈",
    eyebrow: "Для бізнесу",
    title: "Бізнес-бот",
    subtitle: "Запис / FSM / База даних",
    icon: CalendarDays,
    color: "#7c5aff",
    features: [
      "Покроковий онлайн-запис",
      "Вибір послуги, майстра, дати та часу",
      "SQLite / PostgreSQL та SQLAlchemy",
      "Розсилки користувачам",
      "Адмін-панель для власника",
    ],
    stack: "Python · aiogram 3 · SQLite / SQLAlchemy",
    duration: "3–5 днів",
    price: "$90–180",
    priceUah: "≈ 3 600–7 200 грн",
  },
  {
    medal: "🥇",
    eyebrow: "Преміум-рішення",
    title: "Telegram Mini App",
    subtitle: "Повноцінний WebApp усередині Telegram",
    icon: LayoutDashboard,
    color: "#00e887",
    features: [
      "Інтерактивний дашборд або магазин",
      "Сучасний UI/UX з анімаціями",
      "Адаптація під тему Telegram",
      "Збір замовлень та заявок",
      "Налаштування хостингу",
    ],
    stack: "Python · aiogram 3 · HTML5 / CSS3 / JS · WebApp SDK",
    duration: "5–8 днів",
    price: "$200–400+",
    priceUah: "≈ 8 000–16 000+ грн",
  },
];

const addOns = [
  {
    icon: Server,
    title: "Щомісячне обслуговування / Хостинг",
    description: "Підтримка сервера та дрібні правки в тексті.",
    price: "$20–30/міс",
  },
  {
    icon: Plug,
    title: "Інтеграція зі сторонніми API / оплатою",
    description: "Підключення потрібних сервісів і платіжних сценаріїв.",
    price: "+$40–80",
  },
];

const cardVariants: Variants = {
  hidden: { opacity: 0, y: 50 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, delay: i * 0.12 },
  }),
};

function scrollToContact() {
  document.getElementById("contacts")?.scrollIntoView({
    behavior: "smooth",
    block: "start",
  });
}

export function PortfolioSection() {
  const titleRef = useRevealOnMount();

  return (
    <section id="packages" className="py-24 relative" data-testid="pricing-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="text-center mb-16 reveal-hidden">
          <span
            className="inline-block mb-3 text-xs font-mono text-primary/80 tracking-widest uppercase"
            style={{ fontFamily: "var(--app-font-mono)" }}
          >
            Прозорий прайс
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white">
            Пакети та ціни
          </h2>
          <p className="mt-4 text-base text-white/50 font-sans max-w-2xl mx-auto">
            Оберіть формат під вашу задачу — від простої заявки до повноцінного
            магазину всередині Telegram.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
          {packages.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.title}
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                variants={cardVariants}
                whileHover={{ y: -6, transition: { duration: 0.2 } }}
                className="glass-card rounded-2xl p-7 flex flex-col group"
                data-testid={`package-card-${i}`}
              >
                <div className="flex items-start justify-between gap-4 mb-6">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{
                      background: `${item.color}18`,
                      border: `1px solid ${item.color}45`,
                    }}
                  >
                    <Icon className="w-6 h-6" style={{ color: item.color }} />
                  </div>
                  <div className="text-right">
                    <div className="text-2xl leading-none mb-1">{item.medal}</div>
                    <span
                      className="text-[10px] font-mono uppercase tracking-wider"
                      style={{ color: item.color }}
                    >
                      {item.eyebrow}
                    </span>
                  </div>
                </div>

                <h3 className="font-serif font-semibold text-2xl text-white mb-1 group-hover:text-primary transition-colors">
                  {item.title}
                </h3>
                <p className="text-sm text-white/50 font-sans mb-6">{item.subtitle}</p>

                <ul className="flex flex-col gap-3 mb-7 flex-1">
                  {item.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2.5 text-sm text-white/70 font-sans">
                      <Check className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: item.color }} />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="border-t border-white/10 pt-5 space-y-3 mb-6">
                  <div className="flex items-start gap-2.5 text-xs text-white/45 font-sans">
                    <Database className="w-4 h-4 flex-shrink-0" style={{ color: item.color }} />
                    <span>{item.stack}</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-white/45 font-sans">
                    <CalendarDays className="w-4 h-4 flex-shrink-0" style={{ color: item.color }} />
                    <span>Термін: {item.duration}</span>
                  </div>
                </div>

                <div className="flex items-end justify-between gap-4 mb-6">
                  <div>
                    <div className="font-mono text-2xl font-bold text-white">{item.price}</div>
                    <div className="font-mono text-[10px] text-white/40">{item.priceUah}</div>
                  </div>
                  <span className="text-xs text-white/35 font-sans">під ключ</span>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full font-sans border-primary/30 text-white/70 hover:text-white hover:border-primary/60 gap-2"
                  onClick={scrollToContact}
                  data-testid={`button-package-contact-${i}`}
                >
                  Обговорити пакет
                  <ArrowRight className="w-3.5 h-3.5" />
                </Button>
              </motion.div>
            );
          })}
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
          {addOns.map((item) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                className="glass-card rounded-xl p-5 flex items-center gap-4"
                data-testid="addon-card"
              >
                <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 bg-primary/10 border border-primary/25">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1">
                    <h4 className="text-sm font-semibold text-white font-sans">{item.title}</h4>
                    <span className="font-mono text-sm text-primary">{item.price}</span>
                  </div>
                  <p className="text-xs text-white/45 font-sans mt-1">{item.description}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      <div className="section-glow-divider mt-24 mx-8" />
    </section>
  );
}