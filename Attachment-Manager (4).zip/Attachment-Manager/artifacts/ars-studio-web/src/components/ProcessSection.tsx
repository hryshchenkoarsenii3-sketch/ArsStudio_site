import { motion, type Variants } from "framer-motion";
import { useRevealOnMount } from "../hooks/useScrollReveal";

const steps = [
  {
    number: "01",
    title: "Бриф і ТЗ",
    description: "Фіксуємо завдання, логіку й архітектуру. Визначаємо ключові сценарії та метрики успіху.",
  },
  {
    number: "02",
    title: "Прототип і UI",
    description: "Продумуємо зручні сценарії діалогів та інтерфейс WebApp. Узгоджуємо з командою.",
  },
  {
    number: "03",
    title: "Розробка і тести",
    description: "Пишемо чистий код на Python/Aiogram, підключаємо бази даних і платежі. Повне покриття тестами.",
  },
  {
    number: "04",
    title: "Деплой і підтримка",
    description: "Налаштовуємо сервер, передаємо права та надаємо 30 днів безкоштовної технічної підтримки.",
  },
];

const itemVariants: Variants = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.15 },
  }),
};

export function ProcessSection() {
  const titleRef = useRevealOnMount();

  return (
    <section id="process" className="py-24 relative" data-testid="process-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title */}
        <div ref={titleRef} className="text-center mb-20 reveal-hidden">
          <span
            className="inline-block mb-3 text-xs font-mono text-primary/80 tracking-widest uppercase"
            style={{ fontFamily: "var(--app-font-mono)" }}
          >
             Як ми працюємо
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white">
             Етапи роботи
          </h2>
          <p className="mt-4 text-base text-white/50 font-sans max-w-xl mx-auto">
             Прозорий процес від брифінгу до запуску.
          </p>
        </div>

        {/* Desktop horizontal timeline */}
        <div className="hidden lg:block">
          {/* Connecting line */}
          <div className="relative flex items-start">
            <div className="absolute top-8 left-[12.5%] right-[12.5%] timeline-line" />

            {/* Steps */}
            <div className="relative z-10 grid grid-cols-4 gap-6 w-full">
              {steps.map((step, i) => (
                <motion.div
                  key={step.number}
                  custom={i}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: "-40px" }}
                  variants={itemVariants}
                  className="flex flex-col items-center text-center"
                  data-testid={`process-step-${i}`}
                >
                  {/* Circle */}
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center mb-6 flex-shrink-0"
                    style={{
                      background: "rgba(9, 13, 23, 0.9)",
                      border: "2px solid rgba(0, 136, 204, 0.6)",
                      boxShadow: "0 0 16px rgba(0, 136, 204, 0.25), inset 0 0 12px rgba(0, 136, 204, 0.08)",
                    }}
                  >
                    <span
                      className="font-mono font-bold text-lg text-gradient-blue"
                      style={{ fontFamily: "var(--app-font-mono)" }}
                    >
                      {step.number}
                    </span>
                  </div>

                  {/* Glass card */}
                  <div className="glass-card rounded-xl p-5 w-full">
                    <h3 className="font-serif font-semibold text-base text-white mb-2">
                      {step.title}
                    </h3>
                    <p className="text-xs font-sans text-white/50 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile vertical timeline */}
        <div className="lg:hidden">
          <div className="relative flex flex-col gap-0">
            {steps.map((step, i) => (
              <motion.div
                key={step.number}
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-30px" }}
                variants={itemVariants}
                className="relative flex gap-6 pb-8"
                data-testid={`process-step-mobile-${i}`}
              >
                {/* Left: number + line */}
                <div className="flex flex-col items-center">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{
                      background: "rgba(9, 13, 23, 0.9)",
                      border: "2px solid rgba(0, 136, 204, 0.6)",
                      boxShadow: "0 0 12px rgba(0, 136, 204, 0.2)",
                    }}
                  >
                    <span
                      className="font-mono font-bold text-sm text-gradient-blue"
                      style={{ fontFamily: "var(--app-font-mono)" }}
                    >
                      {step.number}
                    </span>
                  </div>
                  {i < steps.length - 1 && (
                    <div className="timeline-line-v flex-1 mt-2" />
                  )}
                </div>

                {/* Right: content */}
                <div className="glass-card rounded-xl p-5 flex-1 mb-2">
                  <h3 className="font-serif font-semibold text-base text-white mb-2">
                    {step.title}
                  </h3>
                  <p className="text-sm font-sans text-white/50 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Section divider */}
      <div className="section-glow-divider mt-16 mx-8" />
    </section>
  );
}
