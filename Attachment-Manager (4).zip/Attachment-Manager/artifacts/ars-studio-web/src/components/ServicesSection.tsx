import { motion, type Variants } from "framer-motion";
import { ShoppingCart, Brain, CreditCard, Database } from "lucide-react";
import { useRevealOnMount } from "../hooks/useScrollReveal";

const services = [
  {
    icon: ShoppingCart,
    title: "Telegram WebApps (TMA)",
    description:
      "Повноцінні застосунки та магазини прямо в Telegram. Нативний UX, швидке завантаження, повна інтеграція з ботом.",
  },
  {
    icon: Brain,
    title: "ШІ та нейромережі",
    description:
      "Інтеграція ChatGPT/Claude для розумної підтримки, скриптів продажів і генерації контенту. Ваш бот навчається та зростає.",
  },
  {
    icon: CreditCard,
    title: "E-commerce & Платежи",
    description:
      "Автоматичні каталоги, кошик і прийом платежів (Stripe, LiqPay, Telegram Payments). Продажі без зупинок.",
  },
  {
    icon: Database,
    title: "CRM та автоматизація",
    description:
      "Зв’язка ботів із Google Таблицями, CRM-системами, автоматична видача доступів і розсилки. Нуль ручної роботи.",
  },
];

const cardVariants: Variants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.12 },
  }),
};

export function ServicesSection() {
  const titleRef = useRevealOnMount();

  return (
    <section id="services" className="py-24 relative" data-testid="services-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title */}
        <div ref={titleRef} className="text-center mb-16 reveal-hidden">
          <span
            className="inline-block mb-3 text-xs font-mono text-primary/80 tracking-widest uppercase"
            style={{ fontFamily: "var(--app-font-mono)" }}
          >
             Що ми робимо
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white">
             Наші послуги
          </h2>
          <p className="mt-4 text-base text-white/50 font-sans max-w-xl mx-auto">
             Повний цикл розробки Telegram-рішень — від ідеї до запуску.
          </p>
        </div>

        {/* Cards grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {services.map((service, i) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                variants={cardVariants}
                whileHover={{ y: -4, transition: { duration: 0.2 } }}
                className="glass-card rounded-2xl p-8 cursor-default group"
                data-testid={`service-card-${i}`}
              >
                {/* Icon */}
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-6"
                  style={{
                    background: "rgba(0, 136, 204, 0.12)",
                    border: "1px solid rgba(0, 136, 204, 0.3)",
                  }}
                >
                  <Icon
                    className="w-6 h-6"
                    style={{ color: "#00d2ff" }}
                  />
                </div>

                {/* Title */}
                <h3 className="font-serif font-semibold text-xl text-white mb-3 group-hover:text-primary transition-colors">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="font-sans text-sm text-white/55 leading-relaxed">
                  {service.description}
                </p>

                {/* Decorative corner */}
                <div
                  className="absolute top-4 right-4 w-16 h-16 rounded-full opacity-5 group-hover:opacity-10 transition-opacity"
                  style={{ background: "radial-gradient(circle, #00d2ff 0%, transparent 70%)" }}
                />
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Section divider */}
      <div className="section-glow-divider mt-24 mx-8" />
    </section>
  );
}
