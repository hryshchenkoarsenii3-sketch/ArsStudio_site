import { motion } from "framer-motion";
import { useRevealOnMount } from "../hooks/useScrollReveal";

const TECH_STACK = [
  "Python",
  "Aiogram 3",
  "PostgreSQL",
  "Docker",
  "REST API",
  "React (TMA)",
  "Webhooks",
  "Redis",
  "Nginx",
  "FastAPI",
];

export function TechStackSection() {
  const titleRef = useRevealOnMount();

  return (
    <section id="tech" className="py-24 relative" data-testid="tech-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title */}
        <div ref={titleRef} className="text-center mb-16 reveal-hidden">
          <span
            className="inline-block mb-3 text-xs font-mono text-primary/80 tracking-widest uppercase"
            style={{ fontFamily: "var(--app-font-mono)" }}
          >
             Інструменти
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white">
             Технологічний стек
          </h2>
          <p className="mt-4 text-base text-white/50 font-sans max-w-xl mx-auto">
             Надійні інструменти, перевірені в продакшені.
          </p>
        </div>

        {/* Badges */}
        <motion.div
          className="flex flex-wrap justify-center gap-3"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          variants={{
            hidden: {},
            visible: { transition: { staggerChildren: 0.07 } },
          }}
        >
          {TECH_STACK.map((tech) => (
            <motion.span
              key={tech}
              variants={{
                hidden: { opacity: 0, scale: 0.85 },
                visible: { opacity: 1, scale: 1, transition: { duration: 0.4 } },
              }}
              className="tech-badge px-5 py-2.5 rounded-full text-sm cursor-default select-none"
              data-testid={`tech-badge-${tech.toLowerCase().replace(/\s+/g, "-")}`}
            >
              {tech}
            </motion.span>
          ))}
        </motion.div>

        {/* Decorative background glow */}
        <div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full pointer-events-none opacity-10"
          style={{ background: "radial-gradient(circle, rgba(0,136,204,0.4) 0%, transparent 70%)" }}
        />
      </div>

      {/* Section divider */}
      <div className="section-glow-divider mt-24 mx-8" />
    </section>
  );
}
