import { Header } from "../components/Header";
import { HeroSection } from "../components/HeroSection";
import { ServicesSection } from "../components/ServicesSection";
import { TechStackSection } from "../components/TechStackSection";
import { PortfolioSection } from "../components/PortfolioSection";
import { ProcessSection } from "../components/ProcessSection";
import { ContactSection } from "../components/ContactSection";
import { Footer } from "../components/Footer";
import { FloatingTelegram } from "../components/FloatingTelegram";

export function Home() {
  return (
    <div
      className="min-h-[100dvh] w-full font-sans"
      style={{ background: "#0a0d14", color: "white" }}
    >
      <Header />
      <main>
        <HeroSection />
        <ServicesSection />
        <TechStackSection />
        <PortfolioSection />
        <ProcessSection />
        <ContactSection />
      </main>
      <Footer />
      <FloatingTelegram />
    </div>
  );
}
